"""Legacy utilities module, to be removed in v1."""
