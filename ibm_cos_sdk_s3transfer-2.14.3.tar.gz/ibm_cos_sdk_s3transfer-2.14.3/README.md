# s3transfer - An IBM COS Transfer Manager for Python

`s3transfer` is a Python library for managing IBM COS transfers.
