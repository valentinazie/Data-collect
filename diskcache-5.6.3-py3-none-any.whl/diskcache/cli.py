"""Command line interface to disk cache."""
