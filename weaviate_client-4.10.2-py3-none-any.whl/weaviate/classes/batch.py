from weaviate.collections.classes.batch import Shard

__all__ = [
    "Shard",
]
