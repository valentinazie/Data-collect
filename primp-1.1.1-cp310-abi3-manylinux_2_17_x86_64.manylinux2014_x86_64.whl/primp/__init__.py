from .primp import *

__doc__ = primp.__doc__
if hasattr(primp, "__all__"):
    __all__ = primp.__all__