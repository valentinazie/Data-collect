"""
Entrypoint for pyrunner.
"""

from composio.cli import composio


if __name__ == "__main__":
    composio()
