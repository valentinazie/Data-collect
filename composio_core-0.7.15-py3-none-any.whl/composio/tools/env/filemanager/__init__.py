"""File manager for agents."""

from .file import File


# from .manager import FileManager
