"""Composio tool execution environment."""
