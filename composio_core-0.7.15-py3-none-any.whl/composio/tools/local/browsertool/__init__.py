"""
Browser tool.
"""

from .tool import BrowserTool
