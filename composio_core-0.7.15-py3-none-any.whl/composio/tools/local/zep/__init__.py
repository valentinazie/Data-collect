"""Zep as composio tool."""

from .tool import Zeptool
