"""
Code index tool.
"""

from .tool import CodeFormatTool
