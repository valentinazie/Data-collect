"""This means `python -m pydantic_ai` should run the CLI."""

from ._cli import app

if __name__ == '__main__':
    app()
