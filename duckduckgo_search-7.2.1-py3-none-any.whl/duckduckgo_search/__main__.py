"""For using as 'python3 -m duckduckgo_search'."""

from .cli import cli

if __name__ == "__main__":
    cli(prog_name="duckduckgo_search")
