from enum import Enum


class Mode(Enum):
    SAGEMAKER = 1
    BEDROCK = 2
