# This module ensures overrides are applied early in the import process
# Import overrides to trigger backwards compatibility patches
from .. import overrides  # noqa: F401
