__version__ = "0.1.2"


def get_version() -> str:
    """
    Returns the current version of this lib
    """
    return __version__