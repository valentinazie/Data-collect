# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from ..responses.response_input_text_param import ResponseInputTextParam

InputTextContentParam = ResponseInputTextParam
