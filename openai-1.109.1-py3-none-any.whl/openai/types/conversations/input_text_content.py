# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..responses.response_input_text import ResponseInputText

__all__ = ["InputTextContent"]

InputTextContent = ResponseInputText
