#  -----------------------------------------------------------------------------------------
#  (C) Copyright IBM Corp. 2023-2026.
#  https://opensource.org/licenses/BSD-3-Clause
#  -----------------------------------------------------------------------------------------


class GlobalizationUtil:
    @staticmethod
    def get_language() -> str:
        language = "en"
        return language
