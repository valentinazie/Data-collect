class UpstashError(Exception):
    pass


class ClientError(Exception):
    pass
