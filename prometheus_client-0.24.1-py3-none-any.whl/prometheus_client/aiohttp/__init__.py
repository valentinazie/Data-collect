from .exposition import make_aiohttp_handler

__all__ = [
    "make_aiohttp_handler",
]
