.. ref_config:

================
Config Reference
================

ibm_botocore.config
---------------

.. autoclass:: ibm_botocore.config.Config
   :members:
