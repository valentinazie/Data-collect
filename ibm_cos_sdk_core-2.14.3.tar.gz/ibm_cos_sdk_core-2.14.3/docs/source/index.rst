Welcome to IBM COS Core Library for Python
=====================================

ibm_botocore is a low-level interface to a growing number of S3 compatible
Services.  ibm_botocore is a key component in the ibm_boto3 project.


Contents:

.. toctree::
   :maxdepth: 2
   :glob:

   tutorial/index
   reference/*
   topics/index
   development/index


Upgrade Notes
=============

Upgrading to 2.0.0
------------------


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
