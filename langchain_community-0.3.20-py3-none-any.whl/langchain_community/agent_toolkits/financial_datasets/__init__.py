"""financial datasets toolkit."""
